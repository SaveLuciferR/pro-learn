// import { logger } from "../../../../../../frontend/src";

// logger();

console.log("КУfdfdsК");