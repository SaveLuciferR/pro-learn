#include <iostream>
using namespace std;


int main(int args, char const *argv []) {
    cout << "C++ is cool" << endl;
    return 0;
}